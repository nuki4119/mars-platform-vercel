// functions/boost-handler/index.ts
import { serve } from 'https://deno.land/std@0.170.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

serve(async (req) => {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  );

  const { user_id, post_id } = await req.json();

  const { data: post, error: postError } = await supabase
    .from('buzz_posts')
    .select('user_id')
    .eq('id', post_id)
    .single();

  if (postError || !post) {
    return new Response(JSON.stringify({ error: 'Post not found.' }), { status: 404 });
  }

  if (post.user_id === user_id) {
    return new Response(JSON.stringify({ error: 'Cannot boost your own post.' }), { status: 400 });
  }

  const result = await supabase.from('ledger_entries').insert([
    {
      type: 'DEBIT',
      user_id,
      amount: 110,
      description: 'Manual Boost Initiated',
      ref_post_id: post_id,
    },
  ]);

  if (result.error) {
    return new Response(JSON.stringify({ error: result.error.message }), { status: 500 });
  }

  return new Response(JSON.stringify({ success: true }), { status: 200 });
});