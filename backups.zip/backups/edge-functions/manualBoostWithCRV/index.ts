// supabase/functions/manualBoostWithCRV/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js';
import { v4 as uuidv4 } from 'https://esm.sh/uuid';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

serve(async (req) => {
  try {
    const { userId, postId } = await req.json();
    if (!userId || !postId) {
      return new Response(JSON.stringify({ error: 'Missing userId or postId' }), { status: 400 });
    }

    // 1. Fetch user wallet
    const { data: wallet, error: walletErr } = await supabase
      .from('wallets')
      .select('balance')
      .eq('user_id', userId)
      .single();

    if (walletErr || !wallet) {
      throw new Error('Wallet not found');
    }

    if (wallet.balance < 110) {
      return new Response(JSON.stringify({ error: 'Insufficient balance' }), { status: 403 });
    }

    // 2. Deduct balance from user
    const { error: debitErr } = await supabase.rpc('adjust_wallet_balance', {
      p_user_id: userId,
      p_amount: -110
    });

    if (debitErr) {
      throw new Error(`Wallet debit failed: ${debitErr.message}`);
    }

    // 3. Create boost transaction
    const boostId = uuidv4();
    const { error: boostErr } = await supabase.from('boost_transactions').insert({
      id: boostId,
      user_id: userId,
      post_id: postId,
      method: 'manual',
      status: 'pending'
    });

    if (boostErr) {
      throw new Error(`Boost transaction failed: ${boostErr.message}`);
    }

    // 4. Update post boost count
    await supabase.rpc('increment_post_boost_count', { p_post_id: postId });

    // 5. Call CRV distribution
    const { error: crvErr } = await supabase.functions.invoke('distributeCRV', {
      body: { userId, postId, boostId, type: 'manual' },
    });

    if (crvErr) {
      throw new Error(`CRV distribution failed: ${crvErr.message}`);
    }

    return new Response(JSON.stringify({ status: 'success', boostId }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
});
